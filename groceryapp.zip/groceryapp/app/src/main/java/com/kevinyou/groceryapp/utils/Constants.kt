package com.kevinyou.groceryapp.utils

object Constants {
    const val TAG : String = "로그"
}


